import os
import pickle

import faiss
import numpy as np
from flask import Flask, jsonify, render_template, request
from sentence_transformers import SentenceTransformer

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INDEX_PATH = os.path.join(BASE_DIR, "qna_index.faiss")
DATA_PATH = os.path.join(BASE_DIR, "qna_data.pkl")
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

model = SentenceTransformer(MODEL_NAME)
if not os.path.exists(INDEX_PATH):
    raise FileNotFoundError(
        "FAISS index not found. Run build_index.py first to create qna_index.faiss."
    )
index = faiss.read_index(INDEX_PATH)

with open(DATA_PATH, "rb") as f:
    qna_data = pickle.load(f)

questions = qna_data["questions"]
answers = qna_data["answers"]

def preprocess_text(text):
    """Simple preprocessing: lowercase and strip whitespace"""
    return text.lower().strip()

def find_answer(query, top_k=1, threshold=0.3):
    """Find the most similar question and return match info."""
    processed_query = preprocess_text(query)
    query_embedding = model.encode([processed_query], show_progress_bar=False)
    query_embedding = np.array(query_embedding).astype("float32")
    faiss.normalize_L2(query_embedding)

    distances, indices = index.search(query_embedding, top_k)
    best_idx = int(indices[0][0])
    similarity_score = float(distances[0][0])

    if similarity_score < threshold:
        return {
            "query": query,
            "matched_question": None,
            "answer": "I'm sorry, I couldn't find a good match for your question. Please try rephrasing or ask about library services.",
            "score": similarity_score,
            "match_found": False,
        }

    return {
        "query": query,
        "matched_question": questions[best_idx],
        "answer": answers[best_idx],
        "score": similarity_score,
        "match_found": True,
    }


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    msg = request.form.get("msg", "")

    if not msg.strip():
        return jsonify({"error": "Please enter a question."}), 400

    result = find_answer(msg)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)