import json
import pickle

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


def clean_text(text):
    """Convert text to lowercase and remove extra spaces."""
    return text.strip().lower()


def create_faiss_index():

    # Read QnA dataset
    with open("qna_data.json", "r") as file:
        records = json.load(file)

    # Separate questions and answers
    question_bank = [record["question"] for record in records]
    answer_bank = [record["answer"] for record in records]

    # Prepare questions for embedding generation
    normalized_questions = [
        clean_text(question)
        for question in question_bank
    ]

    # Load embedding model
    encoder = SentenceTransformer(
        "sentence-transformers/all-MiniLM-L6-v2"
    )

    print("Creating vector embeddings...")

    vectors = encoder.encode(
        normalized_questions,
        show_progress_bar=True
    )

    vectors = np.asarray(vectors, dtype="float32")

    # Build FAISS similarity index
    vector_dimension = vectors.shape[1]

    search_index = faiss.IndexFlatIP(
        vector_dimension
    )

    # Normalize vectors for cosine similarity
    faiss.normalize_L2(vectors)

    # Insert vectors into FAISS
    search_index.add(vectors)

    # Save FAISS index
    faiss.write_index(
        search_index,
        "qna_index.faiss"
    )

    # Save supporting data
    with open("qna_data.pkl", "wb") as file:
        pickle.dump(
            {
                "questions": question_bank,
                "answers": answer_bank,
                "processed_questions": normalized_questions,
            },
            file,
        )

    print(
        f"FAISS index created successfully with {len(question_bank)} question-answer pairs."
    )


if __name__ == "__main__":
    create_faiss_index()