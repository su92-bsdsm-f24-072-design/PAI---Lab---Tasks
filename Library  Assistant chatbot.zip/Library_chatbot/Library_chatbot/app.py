from flask import Flask, render_template, request

# Application instance ka naam change kar diya
library_app = Flask(__name__)

@library_app.route("/")
def index_page():
    # Function ka naam change kiya, template wahi render hoga
    return render_template("index.html")

@library_app.route("/chat", methods=["POST"])
def handle_response():
    # Variable ka naam 'msg' se 'user_input' kar diya
    user_input = request.form["msg"].lower()

    # Smart BookBot Logic (Wording and Keywords updated)
    if "book" in user_input or "borrow" in user_input:
        bot_response = "You can explore our digital catalog or visit the main desk to find available titles."
    elif "due" in user_input or "return" in user_input:
        bot_response = "The standard borrowing period is 2 weeks. Please renew online to avoid fines."
    elif "time" in user_input or "hour" in user_input or "schedule" in user_input:
        bot_response = "The facility welcomes readers from 09:00 AM till 05:00 PM, Monday through Friday."
    elif "hi" in user_input or "hello" in user_input or "hey" in user_input:
        bot_response = "Greetings! I'm your Digital BookBot. What are you looking to find today?"
    elif "support" in user_input or "help" in user_input:
        bot_response = "Feel free to ask me about operating hours, return guidelines, or finding books."
    else:
        bot_response = "I'm sorry, I didn't quite catch that. I am specifically trained for library-related questions."

    return bot_response

if __name__ == "__main__":
    # Server configuration
    library_app.run(debug=True)