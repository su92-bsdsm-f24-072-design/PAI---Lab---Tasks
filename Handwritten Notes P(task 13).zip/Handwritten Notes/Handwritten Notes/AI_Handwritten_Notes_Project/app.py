from flask import Flask, render_template, request
import os

from utils.ocr import extract_text
from utils.summarizer import summarize_text

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    text = ""
    summary = ""

    if request.method == "POST":
        file = request.files["image"]

        if file:
            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)

            text = extract_text(path)
            summary = summarize_text(text)

    return render_template("index.html", text=text, summary=summary)


if __name__ == "__main__":
    app.run(debug=True)