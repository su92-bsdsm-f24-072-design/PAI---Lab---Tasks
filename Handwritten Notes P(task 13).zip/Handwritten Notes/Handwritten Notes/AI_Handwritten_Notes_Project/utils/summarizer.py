from transformers import pipeline

summarizer = pipeline("summarization", model="t5-small")

def summarize_text(text):
    text = text.strip()

    if len(text) < 20:
        return "Not enough readable text for summary"

    text = text[:1000]

    result = summarizer(
        text,
        max_length=120,
        min_length=30,
        do_sample=False
    )

    return result[0]["summary_text"]