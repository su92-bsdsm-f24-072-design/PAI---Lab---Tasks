import easyocr
import cv2
import numpy as np

reader = easyocr.Reader(['en'], gpu=False)

def extract_text(image_path):
    img = cv2.imread(image_path)

    # upscale
    img = cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)

    # grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # denoise
    gray = cv2.bilateralFilter(gray, 11, 17, 17)

    # threshold
    thresh = cv2.adaptiveThreshold(
        gray,255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,2
    )

    result = reader.readtext(thresh, detail=0, paragraph=True)

    return " ".join(result)